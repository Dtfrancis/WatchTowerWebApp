﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WatchTowerWebApp
{
    public partial class Products : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Watch apple1 = new Watch(001, "Amazfit Watch ", "AmazeFit BIP S ", "fit to aid in your day to day task",  70);
            cat1_lb.Text = apple1.category;
            name1_lb.Text = apple1.name;
            info1_lb.Text = apple1.description;
            price1_lb.Text = apple1.unitPrice.ToString();

            Watch amaz1 = new Watch(002, " Apple watch ", "Series 8 Ultra", "Apple's latest smart watch", 800);
            cat2_lb.Text = amaz1.category;
            name2_lb.Text = amaz1.name;
            info2_lb.Text = amaz1.description;
            price2_lb.Text = amaz1.unitPrice.ToString();

            Watch samsung1 = new Watch(003, "Samsung Watch ", "Galaxy Watch 5", "Latest Samsung watch", 350);
            cat3_lb.Text = samsung1.category;
            name3_lb.Text = samsung1.name;
            info3_lb.Text = samsung1.description;
            price3_lb.Text = samsung1.unitPrice.ToString();
        }

        protected void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Web;

namespace WatchTowerWebApp
{
    public class Watch
    {
        public int id { get; }
        public string name { get; set; }
        public string description { get; set; }
        public string category { get; set; }
        public decimal unitPrice { get; private set; }
        public Image image { get; set; }

        public Watch (int a, string d, string b, string c, decimal e)
            {
                this.id = a;
            this.name = b;
            this.description = c;
            this.category = d;
            this.unitPrice = e;           
            }

    }

}